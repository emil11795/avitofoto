
import logging
import os
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
import requests
from bs4 import BeautifulSoup

API_TOKEN = os.getenv("API_TOKEN") or "PASTE_YOUR_BOT_TOKEN_HERE"

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.reply("Привет! Отправь ссылку на объявление Avito, и я скачаю фото без логотипа.")

@dp.message_handler()
async def handle_avito_url(message: types.Message):
    url = message.text.strip()
    if "avito.ru" not in url:
        await message.reply("Это не ссылка на Avito!")
        return

    try:
        headers = {
            "User-Agent": "Mozilla/5.0"
        }
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            await message.reply("⚠️ Не удалось загрузить страницу. Попробуй позже.")
            return

        soup = BeautifulSoup(response.text, "html.parser")
        image_tags = soup.find_all("img")

        image_urls = []
        for tag in image_tags:
            src = tag.get("src")
            if src and "avatars" in src:
                image_urls.append(src)

        if not image_urls:
            await message.reply("📷 Не удалось найти изображения.")
            return

        for img_url in image_urls[:10]:  # Ограничим до 10 картинок
            await message.reply_photo(photo=img_url)

    except Exception as e:
        await message.reply(f"Произошла ошибка: {e}")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
